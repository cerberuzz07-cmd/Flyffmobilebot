/*
 * Cris-Cerberuzz Vision core  v0.2.0
 * One script shared by the PC extension and the Android app.
 *
 * What it does
 *   1. Grabs the game canvas a few times per second.
 *   2. Finds monster name labels by colour, tracks them (#ids) and scores them
 *      by distance / pack size / zone.
 *   3. Taps the best monster, watches the target HP bar to know when it is dead,
 *      fires the skill rotation and potions, then moves on to the next one.
 *   4. Draws an overlay (boxes, ids, scores, zone) so you can see what it sees.
 *
 * API (used by the Android toolbar):
 *   window.__fffBot.start() / stop() / toggle() / setDebug(bool) / status()
 */
(function () {
  'use strict';
  if (window.__fffBot) return;

  const VERSION = '0.2.0';
  const LS_KEY = 'fffbot.cfg.v2';

  // ------------------------------------------------------------------ config
  // All positions are fractions of the game canvas (0..1) so they survive
  // different screen sizes. Distances are shown in "px at 1280 wide".
  const DEFAULTS = {
    inputMode: 'auto',               // auto | native | synthetic | debugger
    scaleW: 1280,                    // frame is downscaled to this width for analysis
    scanMs: 250,                     // time between analyses

    // --- monster detection
    nameColors: [[202, 198, 160]],   // RGB of monster name text (use "Name colour" to re-pick)
    colorTol: 52,                    // RGB distance tolerance
    coreTol: 30,                     // "exact" match: a real label has many of these, blended edges do not
    gapX: 14,                        // joins letters/words of one name (px at 1280)
    gapY: 2,
    label: { minW: 28, maxW: 420, minH: 6, maxH: 36, minFill: 0.10, minCore: 0.35 },
    ignore: [                        // [x0,y0,x1,y1] areas never scanned (HUD, minimap, chat log)
      [0, 0, 1, 0.07],
      [0, 0, 0.15, 0.62],
      [0.86, 0, 1, 0.40],
      [0, 0.82, 1, 1]
    ],
    zone: [0.10, 0.12, 0.90, 0.82],  // only monsters inside this rectangle are attacked
    self: [0.5, 0.66],               // where your character stands on screen
    bodyDy: 0.058,                   // label centre -> monster body, fraction of height
    maxDist: 100000,                 // ignore monsters farther than this (px at 1280)

    // --- target choice
    clusterR: 120,                   // monsters closer than this form a pack
    clusterBonus: 20,                // score bonus per extra monster in the pack
    minHits: 2,                      // frames a monster must be seen before it counts
    trackMove: 80,                   // max movement between scans for the same #id
    trackKeepMs: 1500,

    // --- fight loop
    selectWaitMs: 1200,              // wait for the target bar after tapping a monster
    deadConfirmMs: 900,              // target bar must be gone this long = kill
    attackTimeoutMs: 30000,          // give up on a target after this long
    blacklistMs: 8000,               // skip a monster that could not be selected
    target: { enabled: true, bar: [0.457, 0.578, 0.0185], minCols: 6, blindAttackMs: 6000 },

    // --- bars read from the HUD: [x0, x1, y]
    stats: {
      hp: { bar: [0.0796, 0.1503, 0.0185], color: 'red' },
      mp: { bar: [0.0796, 0.1503, 0.0385], color: 'blue' },
      fp: { bar: [0.0796, 0.1503, 0.0600], color: 'green' }
    },
    pots: [
      { name: 'HP potion', stat: 'hp', below: 0.5, key: '9', cooldown: 3000, enabled: false }
    ],

    // --- skills: use `key` (PC) or `tap: [x, y]` (fractions of the screen, for phones)
    // ifTarget:true  = only while fighting.   ifTarget:false = always (buffs)
    skills: [
      { name: 'Attack', key: '1', every: 1100, ifTarget: true },
      { name: 'Skill 2', key: '2', every: 6000, ifTarget: true, enabled: false },
      { name: 'Buff', key: '0', every: 600000, ifTarget: false, enabled: false }
    ],
    jitter: 5                        // random tap offset in CSS px
  };

  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  function merge(base, extra) {
    if (Array.isArray(extra)) return clone(extra);
    if (extra && typeof extra === 'object') {
      const out = (base && typeof base === 'object' && !Array.isArray(base)) ? Object.assign({}, base) : {};
      for (const k in extra) out[k] = merge(out[k], extra[k]);
      return out;
    }
    return extra === undefined ? base : extra;
  }
  function loadConfig() {
    let saved = null;
    try { saved = JSON.parse(localStorage.getItem(LS_KEY) || 'null'); } catch (e) { }
    return merge(clone(DEFAULTS), saved || {});
  }
  function saveConfig() {
    try { localStorage.setItem(LS_KEY, JSON.stringify(cfg)); } catch (e) { }
  }

  let cfg = loadConfig();

  // ------------------------------------------------------------------- state
  let running = false;
  let debug = false;
  let frame = null;            // {w,h,data,t}
  let tracks = [];
  let nextId = 1;
  let frameNo = 0;
  const blacklist = new Map(); // id -> until
  let live = [];               // tracks seen this frame
  let best = null;
  let bars = { hp: 0, mp: 0, fp: 0, targetCols: 0, targetOn: false };
  let lastTap = null;          // frame coords of last tap (for overlay)
  let bridgeReady = false;
  const S = { state: 'IDLE', targetId: null, tSel: 0, tAtk: 0, lostSince: 0, kills: 0, startedAt: 0, note: '' };
  const skillNext = {};
  const potNext = {};
  let scanTimer = null;
  let busy = false;
  let scanCount = 0;
  let scanMsAvg = 0;

  // ----------------------------------------------------------------- helpers
  const rnd = (a, b) => a + Math.random() * (b - a);
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

  // ----------------------------------------------------------------- capture
  const cap = { want: false, canvas: null, canvasAt: 0, status: 'waiting', rafSeen: false, pending: null };
  const work = document.createElement('canvas');
  let wctx = null;

  const rawRAF = window.requestAnimationFrame;
  window.requestAnimationFrame = function (cb) {
    return rawRAF.call(window, function (t) {
      cap.rafSeen = true;
      try { cb(t); }
      finally {
        if (cap.want) { cap.want = false; const ok = grabFrame(); if (cap.pending) { cap.pending(ok); cap.pending = null; } }
      }
    });
  };

  function pickCanvas() {
    const now = performance.now();
    if (cap.canvas && cap.canvas.isConnected && now - cap.canvasAt < 2000) return cap.canvas;
    let bestC = null, bestA = 0;
    const list = document.getElementsByTagName('canvas');
    for (let i = 0; i < list.length; i++) {
      const c = list[i];
      if (c.id === 'fff-overlay' || c.id === 'fff-work') continue;
      const r = c.getBoundingClientRect();
      const a = r.width * r.height;
      if (r.width >= 200 && r.height >= 150 && a > bestA) { bestA = a; bestC = c; }
    }
    cap.canvas = bestC; cap.canvasAt = now;
    return bestC;
  }

  function isBlank(d, n) {
    let lit = 0;
    for (let i = 0; i < d.length; i += 4 * 97) { if (d[i] + d[i + 1] + d[i + 2] > 30 && d[i + 3] > 0) lit++; }
    return lit < 3;
  }

  function grabFrame() {
    const c = pickCanvas();
    if (!c) { cap.status = 'no game canvas'; return false; }
    if (!c.width || !c.height) { cap.status = 'canvas size 0'; return false; }
    const w = Math.min(cfg.scaleW, c.width);
    const h = Math.round(w * c.height / c.width);
    if (!wctx || work.width !== w || work.height !== h) {
      work.width = w; work.height = h;
      wctx = work.getContext('2d', { willReadFrequently: true });
      wctx.imageSmoothingQuality = 'low';
    }
    try {
      wctx.drawImage(c, 0, 0, w, h);
      const id = wctx.getImageData(0, 0, w, h);
      if (isBlank(id.data)) { cap.status = 'blank frame (canvas not readable)'; return false; }
      frame = { w: w, h: h, data: id.data, t: performance.now() };
      cap.status = 'ok';
      return true;
    } catch (e) {
      cap.status = 'capture error: ' + e.message;
      return false;
    }
  }

  function requestFrame() {
    return new Promise(function (resolve) {
      let done = false;
      const fin = function (v) { if (!done) { done = true; resolve(v); } };
      cap.want = true; cap.pending = fin;
      // If the game never calls requestAnimationFrame through us (or the tab is hidden),
      // fall back to a direct grab (works for 2D canvases / preserved WebGL buffers).
      setTimeout(function () { if (!done) { cap.want = false; cap.pending = null; fin(grabFrame()); } }, 600);
    });
  }

  // --------------------------------------------------------------- detection
  const COLOR_TESTS = {
    red: (r, g, b) => r > 140 && g < 110 && b < 120 && r - g > 70,
    green: (r, g, b) => g > 120 && r < 120 && b < 110 && g - r > 50,
    blue: (r, g, b) => b > 150 && r < 130 && b - r > 60
  };

  function detectLabels(fr, c) {
    const w = fr.w, h = fr.h, d = fr.data;
    const k = w / 1280;
    const tol2 = c.colorTol * c.colorTol, core2 = c.coreTol * c.coreTol;
    const cols = c.nameColors;
    const mask = new Uint8Array(w * h);
    for (let i = 0, p = 0; i < w * h; i++, p += 4) {
      const r = d[p], g = d[p + 1], b = d[p + 2];
      if (r + g + b < 380) continue;
      for (let j = 0; j < cols.length; j++) {
        const dr = r - cols[j][0], dg = g - cols[j][1], db = b - cols[j][2];
        const dd = dr * dr + dg * dg + db * db;
        if (dd <= tol2) { mask[i] = dd <= core2 ? 2 : 1; break; }
      }
    }
    for (let q = 0; q < c.ignore.length; q++) {
      const rc = c.ignore[q];
      const x0 = Math.max(0, Math.floor(rc[0] * w)), x1 = Math.min(w, Math.ceil(rc[2] * w));
      const y0 = Math.max(0, Math.floor(rc[1] * h)), y1 = Math.min(h, Math.ceil(rc[3] * h));
      for (let y = y0; y < y1; y++) mask.fill(0, y * w + x0, y * w + x1);
    }

    // horizontal runs (letters of a name are joined across gaps up to gapX)
    const gapX = Math.max(1, Math.round(c.gapX * k));
    const gapY = c.gapY;
    const runs = [];
    const rowRuns = new Array(h);
    for (let y = 0; y < h; y++) {
      const row = [];
      const base = y * w;
      let x = 0;
      while (x < w) {
        if (!mask[base + x]) { x++; continue; }
        const x0 = x; let last = x, n = 1, nc = mask[base + x] === 2 ? 1 : 0; x++;
        while (x < w && x - last <= gapX) { if (mask[base + x]) { last = x; n++; if (mask[base + x] === 2) nc++; } x++; }
        if (n >= 2) { const run = { x0: x0, x1: last, y: y, n: n, nc: nc, id: runs.length }; runs.push(run); row.push(run); }
      }
      rowRuns[y] = row;
    }
    const parent = new Int32Array(runs.length);
    for (let i = 0; i < parent.length; i++) parent[i] = i;
    const find = function (a) { while (parent[a] !== a) { parent[a] = parent[parent[a]]; a = parent[a]; } return a; };
    for (let y = 1; y < h; y++) {
      const row = rowRuns[y];
      if (!row.length) continue;
      for (let dy = 1; dy <= gapY + 1 && y - dy >= 0; dy++) {
        const up = rowRuns[y - dy];
        if (!up.length) continue;
        for (let a = 0; a < row.length; a++) for (let b = 0; b < up.length; b++) {
          if (row[a].x0 <= up[b].x1 && up[b].x0 <= row[a].x1) {
            const ra = find(row[a].id), rb = find(up[b].id);
            if (ra !== rb) parent[ra] = rb;
          }
        }
      }
    }
    const blobs = new Map();
    for (let i = 0; i < runs.length; i++) {
      const r = runs[i], root = find(i);
      let bl = blobs.get(root);
      if (!bl) { bl = { x0: r.x0, x1: r.x1, y0: r.y, y1: r.y, n: 0, nc: 0 }; blobs.set(root, bl); }
      if (r.x0 < bl.x0) bl.x0 = r.x0;
      if (r.x1 > bl.x1) bl.x1 = r.x1;
      if (r.y < bl.y0) bl.y0 = r.y;
      if (r.y > bl.y1) bl.y1 = r.y;
      bl.n += r.n; bl.nc += r.nc;
    }
    const L = c.label, out = [];
    blobs.forEach(function (bl) {
      const bw = bl.x1 - bl.x0 + 1, bh = bl.y1 - bl.y0 + 1;
      if (bw < L.minW * k || bw > L.maxW * k) return;
      if (bh < L.minH * k || bh > L.maxH * k) return;
      if (bl.n / (bw * bh) < L.minFill) return;
      if (bl.nc / bl.n < L.minCore) return;
      out.push({ x0: bl.x0, y0: bl.y0, x1: bl.x1, y1: bl.y1, cx: (bl.x0 + bl.x1) / 2, cy: (bl.y0 + bl.y1) / 2, n: bl.n, nc: bl.nc });
    });
    return out;
  }

  function barFill(fr, bar, color) {
    const w = fr.w, h = fr.h, d = fr.data, test = COLOR_TESTS[color] || COLOR_TESTS.red;
    const x0 = Math.round(bar[0] * w), x1 = Math.round(bar[1] * w), yc = Math.round(bar[2] * h);
    let last = -1, cols = 0;
    for (let x = x0; x <= x1; x++) {
      let ok = false;
      for (let y = yc - 1; y <= yc + 1 && !ok; y++) {
        if (y < 0 || y >= h || x < 0 || x >= w) continue;
        const p = (y * w + x) * 4;
        if (test(d[p], d[p + 1], d[p + 2])) ok = true;
      }
      if (ok) { cols++; last = x; }
    }
    return { fill: last < 0 ? 0 : (last - x0) / Math.max(1, x1 - x0), cols: cols };
  }

  // ---------------------------------------------------------------- tracking
  function updateTracks(cands, now) {
    frameNo++;
    const k = frame.w / 1280, maxMove = cfg.trackMove * k;
    const pairs = [];
    for (let ti = 0; ti < tracks.length; ti++) for (let ci = 0; ci < cands.length; ci++) {
      const d = Math.hypot(tracks[ti].x - cands[ci].x, tracks[ti].y - cands[ci].y);
      if (d <= maxMove) pairs.push([d, ti, ci]);
    }
    pairs.sort(function (a, b) { return a[0] - b[0]; });
    const usedT = new Set(), usedC = new Set();
    for (let i = 0; i < pairs.length; i++) {
      const ti = pairs[i][1], ci = pairs[i][2];
      if (usedT.has(ti) || usedC.has(ci)) continue;
      usedT.add(ti); usedC.add(ci);
      const t = tracks[ti], c = cands[ci];
      t.x = c.x; t.y = c.y; t.label = c.label; t.seenAt = frameNo; t.seenMs = now; t.hits++;
    }
    for (let ci = 0; ci < cands.length; ci++) {
      if (usedC.has(ci)) continue;
      const c = cands[ci];
      tracks.push({ id: nextId++, x: c.x, y: c.y, label: c.label, seenAt: frameNo, seenMs: now, hits: 1 });
    }
    tracks = tracks.filter(function (t) { return now - t.seenMs <= cfg.trackKeepMs; });
    live = tracks.filter(function (t) { return t.seenAt === frameNo; });
  }

  function inRect(fx, fy, r) { return fx >= r[0] && fx <= r[2] && fy >= r[1] && fy <= r[3]; }

  function scoreTracks(now) {
    const W = frame.w, H = frame.h, k = W / 1280;
    const sx = cfg.self[0] * W, sy = cfg.self[1] * H;
    for (let i = 0; i < live.length; i++) {
      const t = live[i];
      t.dist = Math.hypot(t.x - sx, t.y - sy) / k;
      t.inZone = inRect(t.x / W, t.y / H, cfg.zone);
      t.black = (blacklist.get(t.id) || 0) > now;
      t.pack = 0; t.packSize = 1;
    }
    // packs = connected groups of in-zone monsters closer than clusterR
    const zone = live.filter(function (t) { return t.inZone; });
    const par = zone.map(function (_, i) { return i; });
    const find = function (a) { while (par[a] !== a) { par[a] = par[par[a]]; a = par[a]; } return a; };
    for (let a = 0; a < zone.length; a++) for (let b = a + 1; b < zone.length; b++) {
      if (Math.hypot(zone[a].x - zone[b].x, zone[a].y - zone[b].y) / k <= cfg.clusterR) par[find(a)] = find(b);
    }
    const sizes = new Map(), ids = new Map();
    zone.forEach(function (_, i) { const r = find(i); sizes.set(r, (sizes.get(r) || 0) + 1); });
    let n = 0;
    zone.forEach(function (t, i) {
      const r = find(i);
      if (!ids.has(r)) ids.set(r, ++n);
      t.pack = ids.get(r); t.packSize = sizes.get(r);
    });
    best = null;
    for (let i = 0; i < live.length; i++) {
      const t = live[i];
      t.score = t.dist - cfg.clusterBonus * (t.packSize - 1);
      t.eligible = t.inZone && !t.black && t.hits >= cfg.minHits && t.dist <= cfg.maxDist;
      if (t.eligible && (!best || t.score < best.score)) best = t;
    }
  }

  // ------------------------------------------------------------------- input
  function keyInfo(k) {
    if (/^[0-9]$/.test(k)) return { key: k, code: 'Digit' + k, vk: 48 + Number(k), text: k };
    if (/^[a-z]$/i.test(k)) return { key: k.toLowerCase(), code: 'Key' + k.toUpperCase(), vk: k.toUpperCase().charCodeAt(0), text: k.toLowerCase() };
    const f = /^F(\d{1,2})$/i.exec(k);
    if (f) return { key: 'F' + f[1], code: 'F' + f[1], vk: 111 + Number(f[1]), text: '' };
    const named = { Escape: [27, 'Escape'], Enter: [13, 'Enter'], Tab: [9, 'Tab'], Space: [32, 'Space'] };
    if (named[k]) return { key: k === 'Space' ? ' ' : k, code: named[k][1], vk: named[k][0], text: k === 'Space' ? ' ' : '' };
    return { key: k, code: k, vk: 0, text: k.length === 1 ? k : '' };
  }

  function inputMode() {
    if (cfg.inputMode === 'auto') return window.FFFNative ? 'native' : 'synthetic';
    return cfg.inputMode;
  }

  function toViewport(fx, fy) {
    const c = pickCanvas();
    if (!c || !frame) return null;
    const r = c.getBoundingClientRect();
    return { x: r.left + fx / frame.w * r.width, y: r.top + fy / frame.h * r.height };
  }

  function postBridge(payload) { window.postMessage({ __fff: 'input', payload: payload }, '*'); }

  function tapViewport(x, y) {
    x += rnd(-cfg.jitter, cfg.jitter); y += rnd(-cfg.jitter, cfg.jitter);
    const mode = inputMode();
    if (mode === 'native' && window.FFFNative) {
      const dpr = window.devicePixelRatio || 1;
      window.FFFNative.tap(x * dpr, y * dpr);
    } else if (mode === 'debugger') {
      postBridge({ type: 'tap', x: x, y: y });
    } else {
      const el = document.elementFromPoint(x, y) || pickCanvas() || document.body;
      const base = { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y, screenX: x, screenY: y, button: 0, pointerId: 1, pointerType: 'mouse', isPrimary: true };
      el.dispatchEvent(new PointerEvent('pointerdown', Object.assign({ buttons: 1 }, base)));
      el.dispatchEvent(new MouseEvent('mousedown', Object.assign({ buttons: 1 }, base)));
      setTimeout(function () {
        el.dispatchEvent(new PointerEvent('pointerup', Object.assign({ buttons: 0 }, base)));
        el.dispatchEvent(new MouseEvent('mouseup', Object.assign({ buttons: 0 }, base)));
        el.dispatchEvent(new MouseEvent('click', Object.assign({ buttons: 0 }, base)));
      }, rnd(35, 80));
    }
  }

  function tapFrame(fx, fy) {
    lastTap = { x: fx, y: fy, t: performance.now() };
    const p = toViewport(fx, fy);
    if (p) tapViewport(p.x, p.y);
  }

  function tapFraction(ax, ay) {
    if (!frame) return;
    tapFrame(ax * frame.w, ay * frame.h);
  }

  function pressKey(k) {
    const mode = inputMode();
    const i = keyInfo(String(k));
    if (mode === 'native' && window.FFFNative) {
      window.FFFNative.key(String(k));
    } else if (mode === 'debugger') {
      postBridge({ type: 'key', key: i.key, code: i.code, vk: i.vk, text: i.text });
    } else {
      const target = (document.activeElement && document.activeElement !== document.body) ? document.activeElement : (pickCanvas() || document);
      const mk = function (type) {
        const ev = new KeyboardEvent(type, { key: i.key, code: i.code, bubbles: true, cancelable: true, view: window });
        Object.defineProperty(ev, 'keyCode', { get: function () { return i.vk; } });
        Object.defineProperty(ev, 'which', { get: function () { return i.vk; } });
        return ev;
      };
      target.dispatchEvent(mk('keydown'));
      setTimeout(function () { target.dispatchEvent(mk('keyup')); }, rnd(40, 90));
    }
  }

  function doAction(a) {
    if (a.tap) tapFraction(a.tap[0], a.tap[1]);
    else if (a.key) pressKey(a.key);
  }

  // ------------------------------------------------------------ fight logic
  function setState(s, note) { S.state = s; if (note !== undefined) S.note = note; }

  function runSkills(now, engaged) {
    let stagger = 0;
    cfg.skills.forEach(function (s, idx) {
      if (s.enabled === false) return;
      if (s.ifTarget !== false && !engaged) return;
      const id = (s.name || '') + '#' + idx;
      if (skillNext[id] === undefined) skillNext[id] = (s.first === false) ? now + s.every : 0;
      if (now < skillNext[id]) return;
      skillNext[id] = now + s.every * rnd(0.92, 1.1);
      stagger += rnd(120, 260);
      setTimeout(function () { if (running) doAction(s); }, stagger);
    });
  }

  function runPots(now) {
    cfg.pots.forEach(function (p, idx) {
      if (p.enabled === false) return;
      const v = bars[p.stat];
      if (v === undefined || v === null) return;
      if (v < p.below && v > 0.001 && now >= (potNext[idx] || 0)) {
        potNext[idx] = now + (p.cooldown || 3000);
        doAction(p);
      }
    });
  }

  function step(now) {
    runPots(now);
    const tOn = bars.targetOn;
    switch (S.state) {
      case 'SEARCH': {
        if (tOn) { S.targetId = null; S.tAtk = now; S.lostSince = 0; setState('ATTACK', 'target already selected'); break; }
        if (!best) { S.note = 'no monsters in zone'; break; }
        S.targetId = best.id; S.tSel = now;
        tapFrame(best.x, best.y);
        setState('SELECT', 'selecting #' + best.id);
        break;
      }
      case 'SELECT': {
        if (tOn) { S.tAtk = now; S.lostSince = 0; setState('ATTACK', 'fighting #' + S.targetId); }
        else if (now - S.tSel > cfg.selectWaitMs) {
          blacklist.set(S.targetId, now + cfg.blacklistMs);
          setState('SEARCH', 'could not select #' + S.targetId);
        }
        break;
      }
      case 'ATTACK': {
        if (!tOn) {
          if (!S.lostSince) S.lostSince = now;
          else if (now - S.lostSince > cfg.deadConfirmMs) {
            S.kills++;
            if (S.targetId) blacklist.set(S.targetId, now + 3000);
            setState('SEARCH', 'target dead');
          }
        } else S.lostSince = 0;
        if (S.state === 'ATTACK' && now - S.tAtk > cfg.attackTimeoutMs) {
          if (S.targetId) blacklist.set(S.targetId, now + cfg.blacklistMs);
          setState('SEARCH', 'attack timeout');
        }
        break;
      }
      default: break;
    }
    runSkills(now, S.state === 'ATTACK' || S.state === 'SELECT');
  }

  // ------------------------------------------------------------ analyse loop
  function analyzeFrame(now) {
    const W = frame.w, H = frame.h;
    const labels = detectLabels(frame, cfg);
    const cands = labels.map(function (l) { return { x: l.cx, y: l.cy + cfg.bodyDy * H, label: l }; });
    updateTracks(cands, now);
    scoreTracks(now);
    const hp = barFill(frame, cfg.stats.hp.bar, cfg.stats.hp.color);
    bars.hp = hp.fill;
    bars.mp = barFill(frame, cfg.stats.mp.bar, cfg.stats.mp.color).fill;
    bars.fp = barFill(frame, cfg.stats.fp.bar, cfg.stats.fp.color).fill;
    if (cfg.target.enabled) {
      const tb = barFill(frame, cfg.target.bar, 'red');
      bars.targetCols = tb.cols;
      bars.targetOn = tb.cols >= cfg.target.minCols;
    } else {
      bars.targetCols = 0;
      bars.targetOn = (S.state === 'SELECT' || S.state === 'ATTACK') && now - S.tSel < cfg.target.blindAttackMs;
    }
  }

  async function scanTick() {
    if (busy || !(running || debug)) return;
    busy = true;
    const t0 = performance.now();
    try {
      const ok = await requestFrame();
      if (ok && frame) {
        const now = performance.now();
        analyzeFrame(now);
        if (running) step(now);
        draw();
        scanCount++;
        scanMsAvg = scanMsAvg * 0.8 + (performance.now() - t0) * 0.2;
      } else { drawStatusOnly(); }
    } catch (e) {
      S.note = 'error: ' + e.message;
      if (window.console) console.error('[fffbot]', e);
    } finally { busy = false; }
  }

  function ensureTimer() {
    if (scanTimer) clearInterval(scanTimer);
    scanTimer = setInterval(scanTick, cfg.scanMs);
  }

  // ----------------------------------------------------------------- overlay
  let ov = null, octx = null;
  function ensureOverlay() {
    if (ov) return true;
    if (!document.body) return false;
    ov = document.createElement('canvas');
    ov.id = 'fff-overlay';
    ov.style.cssText = 'position:fixed;pointer-events:none;z-index:2147483646;';
    document.body.appendChild(ov);
    octx = ov.getContext('2d');
    return true;
  }

  function hideOverlay() { if (ov) octx.clearRect(0, 0, ov.width, ov.height); }
  function drawStatusOnly() { hideOverlay(); }

  function draw() {
    if (!(running || debug) || !frame || !ensureOverlay()) { hideOverlay(); return; }
    const c = pickCanvas(); if (!c) return;
    const r = c.getBoundingClientRect();
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const cw = Math.round(r.width * dpr), ch = Math.round(r.height * dpr);
    if (ov.width !== cw || ov.height !== ch) { ov.width = cw; ov.height = ch; }
    ov.style.left = r.left + 'px'; ov.style.top = r.top + 'px';
    ov.style.width = r.width + 'px'; ov.style.height = r.height + 'px';
    const g = octx;
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.clearRect(0, 0, r.width, r.height);
    const sx = r.width / frame.w, sy = r.height / frame.h;
    const W = frame.w, H = frame.h;
    g.lineWidth = 1.5;

    // zone
    g.setLineDash([6, 4]); g.strokeStyle = 'rgba(255,70,70,.9)';
    g.strokeRect(cfg.zone[0] * W * sx, cfg.zone[1] * H * sy, (cfg.zone[2] - cfg.zone[0]) * W * sx, (cfg.zone[3] - cfg.zone[1]) * H * sy);
    g.setLineDash([]);
    // self
    const px = cfg.self[0] * W * sx, py = cfg.self[1] * H * sy;
    g.strokeStyle = '#4af'; g.beginPath(); g.arc(px, py, 9, 0, 7); g.moveTo(px - 14, py); g.lineTo(px + 14, py); g.moveTo(px, py - 14); g.lineTo(px, py + 14); g.stroke();
    // bar sampling rows
    const barLine = function (bar, col) {
      g.strokeStyle = col; g.beginPath();
      g.moveTo(bar[0] * W * sx, bar[2] * H * sy); g.lineTo(bar[1] * W * sx, bar[2] * H * sy); g.stroke();
    };
    barLine(cfg.stats.hp.bar, bars.hp < 0.5 ? '#f55' : '#5f5');
    barLine(cfg.target.bar, bars.targetOn ? '#fa0' : '#888');

    g.font = '11px sans-serif'; g.textBaseline = 'bottom';
    const lbl = function (txt, x, y, col) {
      g.lineWidth = 3; g.strokeStyle = 'rgba(0,0,0,.85)'; g.strokeText(txt, x, y);
      g.lineWidth = 1.5; g.fillStyle = col; g.fillText(txt, x, y);
    };
    const k = frame.w / 1280;
    for (let i = 0; i < live.length; i++) {
      const t = live[i];
      const isTarget = S.targetId === t.id && (S.state === 'ATTACK' || S.state === 'SELECT');
      const isBest = best && best.id === t.id;
      const col = isTarget ? '#ffa500' : isBest ? '#ffffff' : t.black ? '#f66' : t.inZone ? '#3f6' : '#888';
      const bx = t.x * sx, by = t.y * sy, s = 8;
      // label box
      g.lineWidth = 1; g.strokeStyle = 'rgba(0,200,255,.55)';
      g.strokeRect(t.label.x0 * sx, t.label.y0 * sy, (t.label.x1 - t.label.x0) * sx, (t.label.y1 - t.label.y0) * sy);
      // body box
      g.lineWidth = isTarget || isBest ? 2.5 : 1.5; g.strokeStyle = col;
      g.strokeRect(bx - s, by - s, s * 2, s * 2);
      lbl('CS ' + Math.round(t.score) + ' \u00b7 ' + Math.round(t.dist) + 'px \u00b7 pack ' + (t.pack || '-') + (t.packSize > 1 ? 'x' + t.packSize : ''), t.label.x0 * sx, t.label.y0 * sy - 2, col);
      lbl('#' + t.id + (isBest ? '  \u25c4 best' : '') + (isTarget ? '  \u25c4 target' : ''), bx + s + 3, by + s + 11, col);
    }
    if (lastTap && performance.now() - lastTap.t < 900) {
      g.strokeStyle = '#f0f'; g.lineWidth = 2; g.beginPath(); g.arc(lastTap.x * sx, lastTap.y * sy, 13, 0, 7); g.stroke();
    }
  }

  // ------------------------------------------------------------------- panel
  let panel = null, statusEl = null, startBtn = null, dbgBtn = null, cfgBox = null, cfgArea = null;

  function statusText() {
    const mode = inputMode();
    return [
      (running ? 'RUNNING' : 'stopped') + ' \u00b7 ' + S.state + (S.note ? ' \u00b7 ' + S.note : ''),
      'monsters ' + live.length + ' (zone ' + live.filter(function (t) { return t.inZone; }).length + ') \u00b7 kills ' + S.kills,
      'HP ' + Math.round(bars.hp * 100) + '%  target bar ' + (bars.targetOn ? 'ON' : 'off') + (cfg.target.enabled ? '' : ' (blind)'),
      (mode === 'native' && cfg.skills[0] && !cfg.skills[0].tap ? 'hint: Settings > Attack button (phones have no hotkeys)\n' : '') +
      'capture: ' + cap.status + ' \u00b7 ' + Math.round(scanMsAvg) + 'ms \u00b7 input: ' + mode + (mode === 'debugger' && !bridgeReady ? ' (bridge missing!)' : '')
    ].join('\n');
  }

  function refreshPanel() {
    if (!panel) return;
    statusEl.textContent = statusText();
    startBtn.textContent = running ? '\u25a0 Stop' : '\u25b6 Start';
    startBtn.style.background = running ? '#b33' : '#2a7';
    dbgBtn.style.background = debug ? '#36c' : '#445';
  }

  function btn(label, fn, bg) {
    const b = document.createElement('button');
    b.textContent = label;
    b.style.cssText = 'margin:2px;padding:6px 9px;border:0;border-radius:6px;color:#fff;font:12px sans-serif;background:' + (bg || '#445') + ';';
    b.addEventListener('click', function (e) { e.preventDefault(); fn(); refreshPanel(); });
    return b;
  }

  function buildPanel() {
    if (panel || !document.body) return;
    panel = document.createElement('div');
    panel.id = 'fff-panel';
    panel.style.cssText = 'position:fixed;left:6px;bottom:6px;z-index:2147483647;font:12px/1.35 sans-serif;color:#fff;max-width:340px;';
    ['pointerdown', 'pointerup', 'mousedown', 'mouseup', 'click', 'touchstart', 'touchend', 'keydown', 'keyup', 'keypress', 'wheel'].forEach(function (ev) {
      panel.addEventListener(ev, function (e) { e.stopPropagation(); });
    });
    const pill = btn('FFF', function () { body.style.display = body.style.display === 'none' ? 'block' : 'none'; }, '#223');
    pill.style.opacity = '.85';
    const body = document.createElement('div');
    body.style.cssText = 'display:none;background:rgba(10,14,28,.88);padding:6px;border-radius:8px;margin-top:4px;';
    startBtn = btn('\u25b6 Start', function () { running ? stop() : start(); });
    dbgBtn = btn('Debug', function () { setDebug(!debug); });
    const cfgBtn = btn('\u2699 Settings', function () {
      cfgBox.style.display = cfgBox.style.display === 'none' ? 'block' : 'none';
      cfgArea.value = JSON.stringify(cfg, null, 1);
    });
    statusEl = document.createElement('div');
    statusEl.style.cssText = 'white-space:pre;font:11px/1.35 monospace;margin:4px 2px;';
    cfgBox = document.createElement('div'); cfgBox.style.display = 'none';
    const calib = document.createElement('div');
    calib.appendChild(btn('Name colour', function () {
      pickPoints(['Tap a monster NAME (the text above its head)'], function (p, getColor) {
        cfg.nameColors = [getColor(p[0].x, p[0].y)]; saveConfig(); S.note = 'name colour = ' + cfg.nameColors[0].join(',');
      });
    }));
    calib.appendChild(btn('My character', function () {
      pickPoints(['Tap your character'], function (p) { cfg.self = [p[0].x / frame.w, p[0].y / frame.h]; saveConfig(); });
    }));
    calib.appendChild(btn('Zone', function () {
      pickPoints(['Tap the TOP-LEFT corner of the hunting area', 'Tap the BOTTOM-RIGHT corner'], function (p) {
        cfg.zone = [Math.min(p[0].x, p[1].x) / frame.w, Math.min(p[0].y, p[1].y) / frame.h, Math.max(p[0].x, p[1].x) / frame.w, Math.max(p[0].y, p[1].y) / frame.h]; saveConfig();
      });
    }));
    calib.appendChild(btn('HP bar', function () {
      pickPoints(['Tap the LEFT end of your red HP bar', 'Tap the RIGHT end of your HP bar'], function (p) {
        cfg.stats.hp.bar = [Math.min(p[0].x, p[1].x) / frame.w, Math.max(p[0].x, p[1].x) / frame.w, ((p[0].y + p[1].y) / 2) / frame.h]; saveConfig();
      });
    }));
    calib.appendChild(btn('Attack button', function () {
      pickPoints(['Tap your ATTACK / skill button on screen'], function (p) {
        const s = cfg.skills[0] || { name: 'Attack', every: 1100, ifTarget: true };
        delete s.key; s.tap = [p[0].x / frame.w, p[0].y / frame.h];
        cfg.skills[0] = s; saveConfig(); S.note = 'attack button saved';
      });
    }));
    calib.appendChild(btn('Target bar', function () {
      pickPoints(['Select a monster first, then tap the LEFT end of its HP bar', 'Tap the RIGHT end of the monster HP bar'], function (p) {
        cfg.target.bar = [Math.min(p[0].x, p[1].x) / frame.w, Math.max(p[0].x, p[1].x) / frame.w, ((p[0].y + p[1].y) / 2) / frame.h]; saveConfig();
      });
    }));
    cfgArea = document.createElement('textarea');
    cfgArea.style.cssText = 'width:320px;height:160px;font:10px monospace;background:#111;color:#cde;border:1px solid #445;';
    cfgArea.addEventListener('keydown', function (e) { e.stopPropagation(); });
    const save = btn('Save', function () {
      try { cfg = merge(clone(DEFAULTS), JSON.parse(cfgArea.value)); saveConfig(); ensureTimer(); S.note = 'settings saved'; }
      catch (e) { S.note = 'bad JSON: ' + e.message; }
    }, '#2a7');
    const reset = btn('Reset', function () { cfg = clone(DEFAULTS); saveConfig(); cfgArea.value = JSON.stringify(cfg, null, 1); ensureTimer(); S.note = 'settings reset'; }, '#a52');
    cfgBox.appendChild(calib); cfgBox.appendChild(cfgArea); cfgBox.appendChild(document.createElement('br')); cfgBox.appendChild(save); cfgBox.appendChild(reset);
    body.appendChild(startBtn); body.appendChild(dbgBtn); body.appendChild(cfgBtn); body.appendChild(statusEl); body.appendChild(cfgBox);
    panel.appendChild(pill); panel.appendChild(body);
    document.body.appendChild(panel);
    setInterval(refreshPanel, 500);
  }

  // Tap-to-calibrate overlay. Calls done(points in frame coords, getColor)
  function pickPoints(prompts, done) {
    if (!frame) { S.note = 'no frame yet - turn Debug on first'; return; }
    const o = document.createElement('div');
    o.style.cssText = 'position:fixed;left:0;top:0;right:0;bottom:0;z-index:2147483647;background:rgba(0,0,0,.28);touch-action:none;cursor:crosshair;';
    const msg = document.createElement('div');
    msg.style.cssText = 'position:absolute;top:10px;left:50%;transform:translateX(-50%);background:#000d;color:#fff;padding:8px 12px;border-radius:8px;font:14px sans-serif;text-align:center;max-width:80%;';
    o.appendChild(msg);
    const pts = [];
    const show = function () { msg.textContent = prompts[pts.length] + '   (Esc / double-tap = cancel)'; };
    show();
    let lastDown = 0;
    o.addEventListener('pointerdown', function (e) {
      e.preventDefault(); e.stopPropagation();
      const now = Date.now();
      if (now - lastDown < 300) { o.remove(); return; }
      lastDown = now;
      const c = pickCanvas(); if (!c) { o.remove(); return; }
      const r = c.getBoundingClientRect();
      pts.push({ x: (e.clientX - r.left) / r.width * frame.w, y: (e.clientY - r.top) / r.height * frame.h });
      if (pts.length < prompts.length) { show(); return; }
      o.remove();
      requestFrame().then(function () { done(pts, sampleColor); refreshPanel(); });
    });
    window.addEventListener('keydown', function esc(e) { if (e.key === 'Escape') { o.remove(); window.removeEventListener('keydown', esc, true); } }, true);
    document.body.appendChild(o);
  }

  function sampleColor(fx, fy) {
    const d = frame.data, w = frame.w, h = frame.h, R = 7, list = [];
    for (let y = Math.max(0, Math.round(fy) - R); y <= Math.min(h - 1, Math.round(fy) + R); y++)
      for (let x = Math.max(0, Math.round(fx) - R); x <= Math.min(w - 1, Math.round(fx) + R); x++) {
        const p = (y * w + x) * 4; list.push([d[p], d[p + 1], d[p + 2], d[p] + d[p + 1] + d[p + 2]]);
      }
    list.sort(function (a, b) { return b[3] - a[3]; });
    const top = list.slice(0, Math.max(5, Math.round(list.length * 0.12)));
    const med = function (i) { const v = top.map(function (q) { return q[i]; }).sort(function (a, b) { return a - b; }); return v[Math.floor(v.length / 2)]; };
    return [med(0), med(1), med(2)];
  }

  // -------------------------------------------------------------- public API
  function notifyNative() {
    try { if (window.FFFNative && window.FFFNative.botState) window.FFFNative.botState(running); } catch (e) { }
  }
  function start() {
    if (running) return;
    running = true; notifyNative(); S.startedAt = performance.now(); S.kills = 0; S.note = '';
    Object.keys(skillNext).forEach(function (k) { delete skillNext[k]; });
    setState('SEARCH'); ensureTimer(); refreshPanel();
  }
  function stop() { running = false; notifyNative(); setState('IDLE', ''); if (!debug) hideOverlay(); refreshPanel(); }
  function setDebug(on) { debug = !!on; if (!debug && !running) hideOverlay(); ensureTimer(); refreshPanel(); }

  window.__fffBot = {
    version: VERSION,
    start: start, stop: stop,
    toggle: function () { running ? stop() : start(); },
    setDebug: setDebug,
    toggleDebug: function () { setDebug(!debug); },
    setConfig: function (c) { cfg = merge(cfg, c); saveConfig(); ensureTimer(); },
    getConfig: function () { return clone(cfg); },
    status: function () {
      return {
        running: running, state: S.state, note: S.note, kills: S.kills, capture: cap.status, input: inputMode(),
        monsters: live.map(function (t) { return { id: t.id, x: Math.round(t.x), y: Math.round(t.y), dist: Math.round(t.dist), score: Math.round(t.score), inZone: t.inZone, pack: t.pack }; }),
        best: best ? best.id : null, bars: bars, frame: frame ? { w: frame.w, h: frame.h } : null
      };
    },
    _tickForTest: scanTick,
    _detect: function (fr, c) { return detectLabels(fr, c || cfg); },
    _barFill: barFill
  };

  window.addEventListener('message', function (e) {
    if (e.source === window && e.data && e.data.__fffBridge === 'ready') bridgeReady = true;
  });

  // Mount the panel as soon as the game canvas exists.
  ensureTimer();
  const mountTimer = setInterval(function () {
    if (document.body && pickCanvas()) { buildPanel(); ensureOverlay(); clearInterval(mountTimer); }
  }, 800);
})();
