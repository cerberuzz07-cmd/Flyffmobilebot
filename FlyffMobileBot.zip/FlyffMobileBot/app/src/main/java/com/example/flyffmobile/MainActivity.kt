package com.example.flyffmobile

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.InputDevice
import android.view.KeyCharacterMap
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature

class MainActivity : AppCompatActivity() {

    private class Tab(
        val id: Int,
        val webView: WebView,
        val button: Button,
        var botOn: Boolean = false
    )

    /**
     * Exposed to the page as window.FFFNative.
     * Sends real (trusted) touches and key presses straight into the WebView, which games
     * accept far more reliably than synthetic DOM events.
     * Coordinates arrive in physical pixels relative to the WebView.
     */
    private class NativeBridge(
        private val wv: WebView,
        private val onBotState: (Boolean) -> Unit
    ) {
        private val handler = Handler(Looper.getMainLooper())

        @JavascriptInterface
        fun tap(x: Double, y: Double) {
            handler.post {
                val fx = x.toFloat()
                val fy = y.toFloat()
                val downTime = SystemClock.uptimeMillis()
                val down = MotionEvent.obtain(downTime, downTime, MotionEvent.ACTION_DOWN, fx, fy, 0)
                down.source = InputDevice.SOURCE_TOUCHSCREEN
                wv.dispatchTouchEvent(down)
                down.recycle()
                handler.postDelayed({
                    val up = MotionEvent.obtain(
                        downTime, SystemClock.uptimeMillis(), MotionEvent.ACTION_UP, fx, fy, 0
                    )
                    up.source = InputDevice.SOURCE_TOUCHSCREEN
                    wv.dispatchTouchEvent(up)
                    up.recycle()
                }, 60)
            }
        }

        @JavascriptInterface
        fun key(k: String) {
            handler.post {
                val named = when (k) {
                    "Escape" -> KeyEvent.KEYCODE_ESCAPE
                    "Enter" -> KeyEvent.KEYCODE_ENTER
                    "Tab" -> KeyEvent.KEYCODE_TAB
                    "Space" -> KeyEvent.KEYCODE_SPACE
                    else -> -1
                }
                if (named != -1) {
                    wv.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, named))
                    wv.dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_UP, named))
                } else {
                    val events = KeyCharacterMap
                        .load(KeyCharacterMap.VIRTUAL_KEYBOARD)
                        .getEvents(k.toCharArray())
                    events?.forEach { wv.dispatchKeyEvent(it) }
                }
            }
        }

        /** Called by bot.js whenever the bot is started or stopped (so the toolbar stays in sync). */
        @JavascriptInterface
        fun botState(on: Boolean) {
            onBotState(on)
        }
    }

    private val tabs = mutableListOf<Tab>()
    private var activeIndex = -1
    private var nextId = 1

    private lateinit var tabBar: LinearLayout
    private lateinit var webContainer: FrameLayout
    private lateinit var btnBot: Button
    private lateinit var botScript: String

    companion object {
        private const val GAME_URL = "https://universe.flyff.com/play"
        private const val GAME_ORIGIN = "https://universe.flyff.com"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        botScript = assets.open("bot.js").bufferedReader(Charsets.UTF_8).use { it.readText() }

        tabBar = findViewById(R.id.tabBar)
        webContainer = findViewById(R.id.webContainer)
        btnBot = findViewById(R.id.btnBot)

        findViewById<Button>(R.id.btnAddTab).setOnClickListener { addTab() }
        btnBot.setOnClickListener { toggleBot() }
        findViewById<Button>(R.id.btnDebug).setOnClickListener {
            active()?.webView?.evaluateJavascript(
                "window.__fffBot && window.__fffBot.toggleDebug();", null
            )
        }
        findViewById<Button>(R.id.btnReload).setOnClickListener {
            active()?.let {
                it.botOn = false
                it.webView.reload()
                refreshUi()
            }
        }
        findViewById<Button>(R.id.btnKeyboard).setOnClickListener {
            active()?.let {
                it.webView.requestFocus()
                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0)
            }
        }
        findViewById<Button>(R.id.btnClose).setOnClickListener { closeActiveTab() }

        addTab()
    }

    private fun active(): Tab? = tabs.getOrNull(activeIndex)

    @SuppressLint("SetJavaScriptEnabled")
    private fun addTab() {
        val id = nextId++
        var tabRef: Tab? = null
        val wv = WebView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            // Separate storage per tab so each client can log into a different account.
            try {
                if (WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
                    ProfileStore.getInstance().getOrCreateProfile("client$id")
                    WebViewCompat.setProfile(this, "client$id")
                }
            } catch (_: Exception) {
            }
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.userAgentString = settings.userAgentString.replace("; wv", "")

            addJavascriptInterface(
                NativeBridge(this) { on ->
                    runOnUiThread {
                        tabRef?.let {
                            it.botOn = on
                            refreshUi()
                        }
                    }
                },
                "FFFNative"
            )

            // Inject the bot before the game starts (so it can hook requestAnimationFrame early).
            if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
                WebViewCompat.addDocumentStartJavaScript(this, botScript, setOf(GAME_ORIGIN))
            }
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String?) {
                    // Fallback for WebViews without document-start support (the script guards against double-load).
                    view.evaluateJavascript(botScript, null)
                }
            }
            // Inactive tabs stay VISIBLE but fully transparent underneath the active one, because
            // Android pauses WebViews that are hidden, which would freeze that client.
            alpha = 0f
        }
        webContainer.addView(wv)

        val btn = Button(this).apply {
            setTextColor(Color.WHITE)
            textSize = 12f
            isAllCaps = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).also { it.marginEnd = 8 }
        }
        val tab = Tab(id, wv, btn)
        tabRef = tab
        btn.setOnClickListener { selectTab(tabs.indexOf(tab)) }
        tabBar.addView(btn)
        tabs.add(tab)

        wv.loadUrl(GAME_URL)
        selectTab(tabs.size - 1)
    }

    private fun selectTab(index: Int) {
        if (index !in tabs.indices) return
        activeIndex = index
        tabs.forEachIndexed { i, t ->
            t.webView.onResume()
            if (i == index) {
                t.webView.alpha = 1f
                t.webView.bringToFront()
            } else {
                t.webView.alpha = 0f
            }
        }
        refreshUi()
    }

    private fun refreshUi() {
        tabs.forEachIndexed { i, t ->
            val isActive = i == activeIndex
            val state = if (isActive) "active" else "background"
            val bot = if (t.botOn) " • bot" else ""
            t.button.text = "${i + 1}. Client ${t.id}\n$state$bot"
            t.button.setBackgroundColor(
                if (isActive) Color.parseColor("#1E3A8A") else Color.parseColor("#2A1B2B")
            )
        }
        val a = active()
        btnBot.text = if (a?.botOn == true) "Bot: ON" else "Bot: OFF"
    }

    private fun toggleBot() {
        val t = active() ?: return
        val call = if (t.botOn) "stop" else "start"
        t.webView.evaluateJavascript("window.__fffBot && window.__fffBot.$call();", null)
        // The page reports back through FFFNative.botState(); flip locally too in case it is not loaded yet.
        t.botOn = !t.botOn
        refreshUi()
    }

    private fun closeActiveTab() {
        if (tabs.size <= 1) return
        val t = active() ?: return
        t.webView.evaluateJavascript("window.__fffBot && window.__fffBot.stop();", null)
        webContainer.removeView(t.webView)
        t.webView.destroy()
        tabBar.removeView(t.button)
        tabs.remove(t)
        selectTab(minOf(activeIndex, tabs.size - 1))
    }

    override fun onDestroy() {
        tabs.forEach { it.webView.destroy() }
        super.onDestroy()
    }
}
