# Flyff Mobile Bot (Android)

Multi-tab Flyff Universe app with a vision bot: it finds monsters on screen, picks the best one,
taps it, watches the target HP bar, fires your skill, then moves to the next monster.
An overlay shows what it sees (green = candidate, white = best, orange = target, red = skipped,
red dashed box = hunting zone, blue cross = your character, magenta ring = last tap).

## Install
1. Open this folder in Android Studio, let Gradle sync, press Run with your phone plugged in.
   (If Gradle says a dependency needs `compileSdk 35`, set `compileSdk = 35` in `app/build.gradle.kts`.)
2. Already have the project open? Replace these and sync:
   - `app/src/main/java/com/example/flyffmobile/MainActivity.kt`
   - `app/src/main/res/layout/activity_main.xml`
   - `app/src/main/assets/bot.js`
   and use `androidx.webkit:webkit:1.12.1` in `app/build.gradle.kts`.

## Build the APK without Android Studio (GitHub)
1. Create a free GitHub repository and upload the **contents** of this folder, so `settings.gradle.kts` sits at the top
   of the repo. The hidden `.github` folder must come along. If your upload skips it, in GitHub press
   **Add file > Create new file**, type `.github/workflows/build-apk.yml` as the name and paste in that file's contents.
2. Open the repo's **Actions** tab and wait for **Build APK** to finish (about 3-5 minutes). If it did not start, run it with **Run workflow**.
3. Open the finished run, download **FlyffMobileBot-apk** at the bottom, unzip it, and install the `.apk` on your phone
   (allow "install unknown apps" when asked).
If the run fails, open it, copy the red error text and send it to me.

## First run
1. Log in. Tap the small **FFF** pill in the game, then **Debug**: boxes and `#ids` should appear on monsters.
2. **Settings**, then tap each calibration button and what it asks for:
   Name colour (a monster's name text), My character, Zone (two corners), HP bar (both ends),
   Target bar (select a monster first, then both ends of its HP bar), **Attack button** (your on-screen skill button).
3. Press **Start** (in the panel or the toolbar's Bot button).

Toolbar: `+` new client tab, Bot on/off, Debug, Reload, Keyboard, Close tab.
Inactive tabs stay alive under the active one, so every client keeps running.

## Settings (JSON in the Settings panel)
- `skills`: `{ "name": "Skill 2", "tap": [0.9, 0.8], "every": 6000, "ifTarget": true }`.
  `tap` is a screen position as fractions; `ifTarget:false` = always (buffs).
- `pots`: tap a potion button when HP drops below a level.
- `clusterBonus` / `clusterR`: how much it prefers monsters standing in a pack.
- `selectWaitMs`, `deadConfirmMs`, `attackTimeoutMs`: fight timings.

## What was tested
Tested with frames from your recording: monster detection (4 of 4, no false positives), id tracking,
target scoring, HP/MP/FP bar reading, the full select / attack / kill / next-target loop, and the overlay.
**Not tested:** the live game (whether its canvas is readable and accepts the taps; the panel's
status line shows `capture: ok` or `blank frame`) and the Android build itself. If Android Studio shows an error, send it to me.

## Not built yet
Walking when no monster is on screen, loot pickup, reacting when attacked while idle, death handling.

Automation breaks Flyff Universe's rules and can get accounts banned. Try an alt first.
